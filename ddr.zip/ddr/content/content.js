// content.js - DOM Analysis and Highlighting

class AIWebGuide {
    constructor() {
        this.highlightedElement = null;
        this.tooltip = null;
        this.overlay = null;
        this.wrongBtn = null;
        this.closeBtn = null;
        this.elementMap = new Map();

        this.init();
    }

    init() {
        // Listen for messages from background/popup
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sendResponse);
            return true; // Keep channel open for async response
        });

        // Check for active session on page load
        this.checkSession();
    }

    handleMessage(message, sendResponse) {
        switch (message.type) {
            case 'GET_DOM_ELEMENTS':
                const elements = this.extractClickableElements();
                const searchInputs = this.extractSearchInputs();
                sendResponse({ success: true, elements: elements, searchInputs: searchInputs });
                break;

            case 'HIGHLIGHT':
                this.highlightElement(message.target, message.tooltip);
                sendResponse({ success: true });
                break;

            case 'CLEAR_HIGHLIGHT':
                this.clearHighlight();
                sendResponse({ success: true });
                break;

            case 'PING':
                sendResponse({ success: true, ready: true });
                break;

            case 'SESSION_CONTINUE':
                // Page navigated but session is still active
                // Re-extract elements and notify background to continue analysis
                this.handleSessionContinue(message.query);
                sendResponse({ success: true });
                break;

            case 'FILL_SEARCH':
                // Auto-fill search input with keyword
                const fillResult = this.fillSearchInput(message.searchInputId, message.keyword);
                sendResponse(fillResult);
                break;

            default:
                sendResponse({ success: false, error: 'Unknown message type' });
        }
    }

    fillSearchInput(searchInputId, keyword) {
        console.log('검색창 자동 입력:', searchInputId, keyword);

        // Find the search input element
        let searchInput = this.elementMap.get(searchInputId);

        if (!searchInput) {
            // Try to find by re-extracting
            this.extractSearchInputs();
            searchInput = this.elementMap.get(searchInputId);
        }

        if (!searchInput) {
            console.error('검색창을 찾을 수 없음:', searchInputId);
            return { success: false, error: '검색창을 찾을 수 없어요.' };
        }

        // Fill in the keyword
        searchInput.value = keyword;
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
        searchInput.dispatchEvent(new Event('change', { bubbles: true }));

        // Focus on the input
        searchInput.focus();

        // Find and highlight the search button
        const searchButton = this.findSearchButton(searchInput);

        return {
            success: true,
            searchButton: searchButton ? {
                id: 'search-btn',
                text: searchButton.innerText || '검색'
            } : null
        };
    }

    findSearchButton(searchInput) {
        // Look for search button near the input
        const parent = searchInput.closest('form') || searchInput.parentElement?.parentElement;

        if (parent) {
            // Find button or submit input
            const button = parent.querySelector('button[type="submit"], input[type="submit"], button:not([type]), .search-btn, [class*="search"]');
            if (button) {
                const id = 'search-btn';
                this.elementMap.set(id, button);
                return button;
            }
        }

        return null;
    }

    async handleSessionContinue(query) {
        console.log('AI Web Guide: Continuing session on new page');

        // Wait for page to stabilize
        await new Promise(resolve => setTimeout(resolve, 500));

        // Re-extract elements for the new page
        this.extractClickableElements();

        // Check with background if we should highlight something
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'PAGE_NAVIGATED'
            });

            if (response && response.found && response.candidate) {
                // Show confirmation tooltip or directly highlight
                this.highlightElement(response.candidate, response.confirmationMessage || '여기를 클릭하세요');
            }
        } catch (error) {
            console.log('AI Web Guide: Error continuing session', error);
        }
    }

    extractClickableElements() {
        const selectors = [
            'button',
            'a[href]',
            'input[type="submit"]',
            'input[type="button"]',
            '[role="button"]',
            '[role="link"]',
            '[onclick]',
            '[tabindex="0"]',
            '.btn',
            '.button'
        ];

        const elements = document.querySelectorAll(selectors.join(', '));
        const elementData = [];
        this.elementMap.clear();

        let index = 0;
        elements.forEach((el) => {
            // Skip hidden or very small elements
            const rect = el.getBoundingClientRect();
            if (rect.width < 10 || rect.height < 10) return;

            const styles = window.getComputedStyle(el);
            if (styles.display === 'none' || styles.visibility === 'hidden' || styles.opacity === '0') return;

            const id = `ai-nav-${index}`;
            const text = this.getElementText(el);

            // Skip elements with no text
            if (!text) return;

            const data = {
                id: id,
                tag: el.tagName.toLowerCase(),
                text: text,
                type: this.getElementType(el),
                href: el.getAttribute('href') || '',
                ariaLabel: el.getAttribute('aria-label') || '',
                title: el.getAttribute('title') || '',
                className: el.className || '',
                rect: {
                    top: rect.top + window.scrollY,
                    left: rect.left + window.scrollX,
                    width: rect.width,
                    height: rect.height
                }
            };

            this.elementMap.set(id, el);
            elementData.push(data);
            index++;
        });

        return elementData;
    }

    extractSearchInputs() {
        const selectors = [
            'input[type="search"]',
            'input[type="text"][name*="search"]',
            'input[type="text"][id*="search"]',
            'input[type="text"][class*="search"]',
            'input[type="text"][placeholder*="검색"]',
            'input[type="text"][placeholder*="찾기"]',
            'input[type="text"][placeholder*="Search"]',
            'input[name="query"]',
            'input[name="q"]',
            'input[name="keyword"]'
        ];

        const inputs = document.querySelectorAll(selectors.join(', '));
        const searchInputData = [];

        let searchIndex = 0;
        inputs.forEach((el) => {
            const rect = el.getBoundingClientRect();
            if (rect.width < 50 || rect.height < 10) return;

            const styles = window.getComputedStyle(el);
            if (styles.display === 'none' || styles.visibility === 'hidden') return;

            const id = `search-${searchIndex}`;
            const data = {
                id: id,
                tag: 'input',
                type: 'search',
                placeholder: el.getAttribute('placeholder') || '검색',
                name: el.getAttribute('name') || '',
                rect: {
                    top: rect.top + window.scrollY,
                    left: rect.left + window.scrollX,
                    width: rect.width,
                    height: rect.height
                }
            };

            this.elementMap.set(id, el);
            searchInputData.push(data);
            searchIndex++;
        });

        return searchInputData;
    }

    getElementText(el) {
        // Try various sources for element text
        let text = el.innerText?.trim() ||
            el.textContent?.trim() ||
            el.getAttribute('aria-label') ||
            el.getAttribute('title') ||
            el.getAttribute('alt') ||
            el.getAttribute('placeholder') ||
            el.getAttribute('value') ||
            '';

        // Limit text length
        if (text.length > 100) {
            text = text.substring(0, 100) + '...';
        }

        return text;
    }

    getElementType(el) {
        const tag = el.tagName.toLowerCase();
        const role = el.getAttribute('role');
        const type = el.getAttribute('type');

        if (role) return role;
        if (tag === 'a') return 'link';
        if (tag === 'button') return 'button';
        if (tag === 'input') return type || 'input';
        return 'clickable';
    }

    highlightElement(target, tooltipText = '여기를 클릭하세요') {
        // Clear any existing highlight
        this.clearHighlight();

        // Find element by ID from our map, or by selector
        let element = null;

        if (target.id && this.elementMap.has(target.id)) {
            element = this.elementMap.get(target.id);
        } else if (target.selector) {
            element = document.querySelector(target.selector);
        } else {
            // Try to find by text content
            element = this.findElementByText(target.text);
        }

        if (!element) {
            console.error('AI Web Guide: Element not found', target);
            return false;
        }

        // Store reference
        this.highlightedElement = element;

        // Scroll element into view
        this.scrollToElement(element);

        // Add overlay
        this.createOverlay();

        // Add highlight class
        element.classList.add('ai-guide-highlight-outline');

        // Create tooltip
        this.createTooltip(element, tooltipText);

        // Create wrong button
        this.createWrongButton();

        // Create close button
        this.createCloseButton();

        // Notify background that element is highlighted
        chrome.runtime.sendMessage({
            type: 'ELEMENT_HIGHLIGHTED',
            target: target
        });

        return true;
    }

    findElementByText(text) {
        if (!text) return null;

        const normalizedText = text.toLowerCase().trim();

        for (const [id, el] of this.elementMap) {
            const elText = this.getElementText(el).toLowerCase();
            if (elText.includes(normalizedText) || normalizedText.includes(elText)) {
                return el;
            }
        }

        return null;
    }

    scrollToElement(element) {
        const rect = element.getBoundingClientRect();
        const isInViewport = (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );

        if (!isInViewport) {
            element.scrollIntoView({
                behavior: 'smooth',
                block: 'center',
                inline: 'center'
            });
        }
    }

    createOverlay() {
        this.overlay = document.createElement('div');
        this.overlay.className = 'ai-guide-overlay';
        document.body.appendChild(this.overlay);
    }

    createTooltip(element, text) {
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'ai-guide-tooltip';

        this.tooltip.innerHTML = `
      <span class="ai-guide-tooltip-icon">👆</span>
      <span class="ai-guide-tooltip-text">${text}</span>
      <span class="ai-guide-tooltip-subtext">노란색으로 표시된 곳을 클릭하세요</span>
    `;

        document.body.appendChild(this.tooltip);

        // Position tooltip
        this.positionTooltip(element);

        // Reposition on scroll/resize
        this.repositionHandler = () => this.positionTooltip(element);
        window.addEventListener('scroll', this.repositionHandler);
        window.addEventListener('resize', this.repositionHandler);
    }

    positionTooltip(element) {
        if (!this.tooltip || !element) return;

        const rect = element.getBoundingClientRect();
        const tooltipRect = this.tooltip.getBoundingClientRect();

        // Default: position above element
        let top = rect.top - tooltipRect.height - 20;
        let left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);

        // If not enough space above, position below
        if (top < 10) {
            top = rect.bottom + 20;
            this.tooltip.classList.remove('tooltip-top');
            this.tooltip.classList.add('tooltip-bottom');
        } else {
            this.tooltip.classList.add('tooltip-top');
            this.tooltip.classList.remove('tooltip-bottom');
        }

        // Keep within viewport horizontally
        if (left < 10) left = 10;
        if (left + tooltipRect.width > window.innerWidth - 10) {
            left = window.innerWidth - tooltipRect.width - 10;
        }

        this.tooltip.style.top = `${top}px`;
        this.tooltip.style.left = `${left}px`;
    }

    createWrongButton() {
        this.wrongBtn = document.createElement('button');
        this.wrongBtn.className = 'ai-guide-wrong-btn';
        this.wrongBtn.innerHTML = '🔄 이게 아니에요';

        this.wrongBtn.addEventListener('click', () => {
            chrome.runtime.sendMessage({ type: 'WRONG_ELEMENT' });
        });

        document.body.appendChild(this.wrongBtn);
    }

    createCloseButton() {
        this.closeBtn = document.createElement('button');
        this.closeBtn.className = 'ai-guide-close-btn';
        this.closeBtn.innerHTML = '✕';
        this.closeBtn.title = '닫기';

        this.closeBtn.addEventListener('click', () => {
            this.clearHighlight();
            chrome.runtime.sendMessage({ type: 'CLEAR_SESSION' });
        });

        document.body.appendChild(this.closeBtn);
    }

    clearHighlight() {
        // Remove highlight class
        if (this.highlightedElement) {
            this.highlightedElement.classList.remove('ai-guide-highlight-outline');
            this.highlightedElement = null;
        }

        // Remove tooltip
        if (this.tooltip) {
            this.tooltip.remove();
            this.tooltip = null;
        }

        // Remove overlay
        if (this.overlay) {
            this.overlay.remove();
            this.overlay = null;
        }

        // Remove wrong button
        if (this.wrongBtn) {
            this.wrongBtn.remove();
            this.wrongBtn = null;
        }

        // Remove close button
        if (this.closeBtn) {
            this.closeBtn.remove();
            this.closeBtn = null;
        }

        // Remove event listeners
        if (this.repositionHandler) {
            window.removeEventListener('scroll', this.repositionHandler);
            window.removeEventListener('resize', this.repositionHandler);
            this.repositionHandler = null;
        }
    }

    async checkSession() {
        try {
            const response = await chrome.runtime.sendMessage({ type: 'CHECK_SESSION_FOR_PAGE' });

            if (response && response.shouldHighlight && response.target) {
                // Small delay to ensure page is fully loaded
                setTimeout(() => {
                    // Re-extract elements for new page
                    this.extractClickableElements();
                    this.highlightElement(response.target, response.tooltip);
                }, 500);
            }
        } catch (error) {
            // No active session, that's fine
            console.log('AI Web Guide: No active session');
        }
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => new AIWebGuide());
} else {
    new AIWebGuide();
}
